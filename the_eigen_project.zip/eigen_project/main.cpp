#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>
#include <random>
#include <Eigen/Dense>

using namespace Eigen;

//HYPER PARAMETERS 
const int filter_size = 3; 

MatrixXd readCSV(const std::string& filePath);
MatrixXd vectorToEigenMatrix(const std::vector<float>& inputVector, int rows, int cols);
MatrixXd conv(const MatrixXd& X, const MatrixXd& K, const float& b);
MatrixXd maxpool(const MatrixXd& input);
MatrixXd r_maxpool(const MatrixXd& R, const MatrixXd& M, const MatrixXd& dM);
MatrixXd relu_prime(MatrixXd zed);
MatrixXd DOT(const MatrixXd& X1, const MatrixXd& X2);
VectorXd readCSVtoVector(const std::string& filename);
void saveMatrixToCSV(const Eigen::MatrixXd& matrix, const std::string& filename);
int argmax(const VectorXd& vect);
Eigen::MatrixXd vect_readCSV(const std::string& filename);
void saveEigenVectorToCSV(const Eigen::VectorXd& eigenVector, const std::string& fileName);
VectorXd updateV(const Eigen::VectorXd& X, const Eigen::VectorXd& dX);
MatrixXd updateM(const Eigen::MatrixXd& X, const Eigen::MatrixXd& dX);

MatrixXd foldX2(const Eigen::VectorXd& Xvect){
    MatrixXd X2(32,169);
    for(int i = 0; i < 32; i++){
    for(int j = 0; j < 169; j++){ 
        X2(i,j) = Xvect(j%169+169*i); 
    }}
    return X2;
}

MatrixXd foldX1(const Eigen::VectorXd& Xvect) {
    MatrixXd X1(13,416);
    for(int i = 0; i < 13; i++){
    for(int j = 0; j < 416; j++){
        X1(i,j) = Xvect(j%13+169*(j/13)+13*i);
    }}
    return X1;
}

MatrixXd foldX0(const Eigen::VectorXd& Xvect) {
    MatrixXd X0(13,416);
    for(int i = 0; i < 13; i++){
    for(int j = 0; j < 130; j++){
        X0(i,j) = Xvect(13*j+i);
    }}
    return X0;
}

MatrixXd foldG2(const Eigen::VectorXd& Gvect){
    MatrixXd G2(20,100);
    for(int i = 0; i < 20; i++){
    for(int j = 0; j < 100; j++){
        G2(i,j) = Gvect(j%100+100*i);
    }}
    return G2;
}

MatrixXd foldG1(const Eigen::VectorXd& Gvect){
    MatrixXd G1(10,200);
    for(int i = 0; i < 10; i++){
    for(int j = 0; j < 200; j++){
        G1(i,j) = Gvect(j%10+100*(j/10)+10*i);
    }}
    return G1;
}

MatrixXd foldG0(const Eigen::VectorXd& Gvect){
    MatrixXd G0(10,200);
    for(int i = 0; i < 10; i++){
    for(int j = 0; j < 200; j++){
        G0(i,j) = Gvect(10*j+i);
    }}
    return G0;
}

MatrixXd kron(const MatrixXd& A, const MatrixXd& B) {
    int rows_A = A.rows();
    int cols_A = A.cols();
    int rows_B = B.rows();
    int cols_B = B.cols();

    MatrixXd result(rows_A * rows_B, cols_A * cols_B);

    for (int i = 0; i < rows_A; ++i) {
        for (int j = 0; j < cols_A; ++j) {
            result.block(i * rows_B, j * cols_B, rows_B, cols_B) = A(i, j) * B;
        }
    }
    return result;
}

VectorXd unfoldM2(const MatrixXd& G2){
    VectorXd ret = VectorXd::Zero(G2.rows() * G2.cols()); 
    for(int i = 0; i < G2.rows(); i++){
        ret.segment(G2.cols() * i, G2.cols()) = G2.row(i);
    }
    return ret; 
}

void saveMatrixToCSV(const Eigen::MatrixXd& matrix, const std::string& filename) {
    std::ofstream file(filename);
    if (file.is_open()) {
        file << matrix.format(Eigen::IOFormat(Eigen::StreamPrecision, Eigen::DontAlignCols, ", ", "\n"));
        file.close();
        std::cout << "Matrix saved to " << filename << std::endl;
    } else {std::cerr << "Error opening file: " << filename << std::endl;}
}

MatrixXd matvec(const Eigen::VectorXd& vect, int dim1, int dim2){
    MatrixXd mat = MatrixXd::Zero(dim1, dim2);
    for(int i = 0; i < dim1; i++){
    for(int j = 0; j < dim2; j++){
        mat(i,j) = vect(i%dim1 + j*dim1); 
    }}
    return mat;
}

MatrixXd permutate(const VectorXd& perm, const MatrixXd& X){
    MatrixXd ret = MatrixXd::Zero(X.rows(),X.cols());
    for(int i = 0; i < X.rows(); i++){
        ret.row(perm(i)) = X.row(i);
    }
    return ret;
}

VectorXd get_permutate(const VectorXd& Wn, const VectorXd& Wm){
    VectorXd ret(Wn.size());

    for(int i = 0; i < Wn.size(); i++){
        for(int j = 0; j < Wm.size(); j++){
            if(Wn(i) == Wm(j)){
                ret(i) = j;
            }
        }
    }
    return ret;
}

const float eta = 0.003; 
const float delta = 0.00000000001;

int main(int argc, char* argv[]){

    //CALCULATING PERMUTATIONS 
    VectorXd practice = VectorXd::Zero(2000);
    for(int i = 0; i < 2000; i++) { practice(i) = i; }
    MatrixXd P2 = foldG2(practice);
    MatrixXd P1 = foldG1(practice);
    MatrixXd P0 = foldG0(practice);

    VectorXd PER2 = get_permutate(P2.reshaped(), P2.reshaped());
    VectorXd PER1 = get_permutate(P1.reshaped(), P2.reshaped());
    VectorXd PER0 = get_permutate(P0.reshaped(), P2.reshaped());

    const int filters = 32; 

    //READING LABELS AND IMAGES
    std::string csvFilePath = "mnist_train.csv";
    MatrixXd csvdata = vect_readCSV(csvFilePath);

    
    VectorXd labels = csvdata.col(0);
    std::cout << "first label: " << labels(0) << std::endl;

    
    MatrixXd images(csvdata.rows(), csvdata.cols() - 1);
    images << csvdata.rightCols(csvdata.cols() - 1);

    //READING PARAMETERS 
    VectorXd Bf = readCSVtoVector("Bf.csv");

    Matrix<double,3,3> K[filters];
    Matrix<double,26,26> Z[filters];
    Matrix<double,26,26> R[filters];
    Matrix<double,13,13> M[filters];

    Matrix<double,3,3> dK[filters];
    Matrix<double,26,26> dZ[filters];
    Matrix<double,26,26> dR[filters];
    Matrix<double,13,13> dM[filters];

    for(int i = 0; i < filters; i++){
        K[i] = readCSV("kernels/K"+std::to_string(i)+".csv");
    }

    VectorXd DLDX;
    VectorXd X;
    VectorXd Y_hat;
    VectorXd dY_hat;

    MatrixXd U0 = readCSV("tensors/U0.csv");
    MatrixXd U1 = readCSV("tensors/U1.csv");
    MatrixXd U2 = readCSV("tensors/U2.csv");

    for(int i = 0; i < filters; i++){ K[i] = readCSV("kernels/K"+std::to_string(i)+".csv"); }

    MatrixXd W = readCSV("W.csv");
    std::cout << "W shape: (" << W.rows() << ", "<< W.cols() << ") " << std::endl; 

    //MAIN LOOP 
    const int trials = 30000;
    const int desired_sample_size = 20000;
    const int sample_size = std::min(desired_sample_size, images.rows());
    const int save = 100; 
    const int measure = 100;

    VectorXd acc = VectorXd::Zero(measure);
    VectorXd err = VectorXd::Zero(measure);

    VectorXd acc_save = VectorXd::Zero(trials);
    VectorXd err_save = VectorXd::Zero(trials);



    for(int trial = 0; trial < trials; trial++){

        //PRELIMINARY CALCULATIONS
        int number = trial%sample_size;
        VectorXd Y_act = VectorXd::Constant(10, 5); Y_act(static_cast<int>(labels(number))) = 10;

        MatrixXd in = images.row(number).reshaped(28,28).transpose();
        MatrixXd input = in/in.norm();
        //std::cout << Y_act << std::endl;
        MatrixXd V = kron(U1,U0).transpose(); 
        MatrixXd U = U2; 

        //FORWARD PROPAGATION 
         for(int i = 0; i < filters; i++){
            Z[i] = conv(input, K[i], Bf(i));
            M[i] = maxpool(Z[i]);
        }
        
        X = VectorXd::Zero(169*filters);
        for(int i = 0; i < filters; i++){
            X.segment(169*i,169) = M[i].reshaped();
        }

        MatrixXd X2 = foldX2(X); 
        MatrixXd G2 = DOT(DOT(U,X2),V);
        VectorXd Gvect = G2.reshaped();    
        
//TENSOR DECOMPOSITION LAYER FORWARD PROPAGATION

        //std::cout << "Gvect.size: " << Gvect.size() << std::endl;
        Y_hat = W*Gvect;
        int right = 0; 
        if(argmax(Y_hat) == argmax(Y_act)) { acc(trial%measure) = 1; right = 1; } 
        else { acc(trial%measure) = 0; }

        // std::cout << "Y_hat: " << Y_hat << std::endl;
        // std::cout << "Y_act: " << Y_act << std::endl;

        dY_hat = Y_hat - Y_act;
        err(trial%measure) = dY_hat.norm();
        if(trial < measure) { for(int i = trial; i < measure; i++){ err(i) = dY_hat.norm(); } }

        std::cout << "TRIAL: " << trial << "\tERROR: " << dY_hat.norm()  
        << "\tACCURACY: " << acc.mean() << "\tERR: " << err.mean() << std::endl;

        //BEGINNING OF BACK PROPAGATION 

        MatrixXd dW = MatrixXd::Zero(W.rows(),W.cols());
        for(int i = 0; i < W.rows(); i++){ 
        for(int j = 0; j < W.cols(); j++){ 
            dW(i,j) = dY_hat(i)*Gvect(j); 
        }}

        VectorXd DLDG = VectorXd::Zero(W.cols());
        for(int i = 0; i < W.cols(); i++){ 
        for(int j = 0; j < W.rows(); j++){ 
            DLDG(i) = DLDG(i) + dY_hat(j)*W(j,i);
        }}

//TENSOR DECOMPOSITION LAYER BACK PROPAGATION
        //DLDX
        MatrixXd DLDG2 = matvec(DLDG,20,100);
        MatrixXd DG2DX2 = kron(V.transpose(),U);
        MatrixXd DLDX2 = matvec(DG2DX2.transpose() * DLDG2.reshaped(), 32,169);
        VectorXd DLDX = unfoldM2(DLDX2);

        //DLDU
        MatrixXd DGDU2 = permutate(PER2, kron(DOT(kron(U1,U0),foldX2(X).transpose()),MatrixXd::Identity(20, 20)));
        MatrixXd DGDU1 = permutate(PER1, kron(DOT(kron(U2,U0),foldX1(X).transpose()),MatrixXd::Identity(10, 10)));
        MatrixXd DGDU0 = permutate(PER0, kron(DOT(kron(U2,U1),foldX0(X).transpose()),MatrixXd::Identity(10, 10)));        


        MatrixXd DLDU2 = DOT(DGDU2.transpose(),DLDG).reshaped(20,32);
        MatrixXd DLDU1 = DOT(DGDU1.transpose(),DLDG).reshaped(10,13);
        MatrixXd DLDU0 = DOT(DGDU0.transpose(),DLDG).reshaped(10,13);


//TENSOR DECOMPOSITION LAYER BACK PROPOGATION
        //ADDITIONAL BACKPROPAGATION
        for(int i = 0; i < filters; i++){
            dM[i] = DLDX.segment(i*169,169).reshaped(13,13); 
            dZ[i] = r_maxpool(Z[i],M[i],dM[i]); 
            dK[i] = conv(input, dZ[i],0); 
        }
        
        //UPDATING WEIGHTS 
        W = updateM(W,dW); 

        U0 = updateM(U0,DLDU0);
        U1 = updateM(U1,DLDU1);
        U2 = updateM(U2,DLDU2);

        for(int i = 0; i < filters; i++){ 
            K[i] = updateM(K[i],dK[i]); 
        }
        


        //SAVING WEIGHTS TO FILES
        if(trial%save == save-1){
            saveMatrixToCSV(W,"W.csv");
            saveMatrixToCSV(U0,"tensors/U0.csv");
            saveMatrixToCSV(U1,"tensors/U1.csv");
            saveMatrixToCSV(U2,"tensors/U2.csv");
            for(int i = 0; i < filters; i++){ 
                saveMatrixToCSV(K[i],"kernels/K"+std::to_string(i)+".csv");
            }
        }
    }
    /**/
    
    std::cout << "hello world " << std::endl;
    return 0; 
}



VectorXd updateV(const Eigen::VectorXd& X, const Eigen::VectorXd& dX){
    float mult = eta*X.norm()/(dX.norm() + delta);
    return X - mult*dX;
}

MatrixXd updateM(const Eigen::MatrixXd& X, const Eigen::MatrixXd& dX){
    float mult = eta*X.norm()/(dX.norm() + delta);
    return X - mult*dX;
}

void saveEigenVectorToCSV(const Eigen::VectorXd& eigenVector, const std::string& fileName) {
    // Open the CSV file for writing
    std::ofstream csvFile(fileName);

    if (csvFile.is_open()) {
        // Write the Eigen vector to the CSV file
        for (int i = 0; i < eigenVector.size(); ++i) {
            csvFile << eigenVector(i);

            // Add a comma if it's not the last element
            if (i < eigenVector.size() - 1) {
                csvFile << ",";
            }
        }

        // Close the CSV file
        csvFile.close();

        std::cout << "Eigen vector saved to " << fileName << std::endl;
    } else {
        std::cerr << "Unable to open CSV file for writing." << std::endl;
    }
}

VectorXd readCSVtoVector(const std::string& filename) {
    // Open the CSV file for reading
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return Eigen::VectorXd();  // Return an empty vector in case of an error
    }

    // Read the data from the CSV file into a temporary vector
    std::vector<double> data;
    double value;

    while (file >> value) {
        data.push_back(value);
        char comma;
        file >> std::ws >> comma; // Read and discard the comma (if any) after each value
    }

    // Close the file
    file.close();

    // Determine the number of elements
    int size = data.size();

    // Create a VectorXd and assign the data
    Eigen::Map<Eigen::VectorXd> vector(data.data(), size);

    return vector;
}

MatrixXd DOT(const MatrixXd& X1, const MatrixXd& X2){
    if(X1.cols() != X2.rows()){ std::cout << "X1.cols() != X2.rows()" << std::endl; }
    MatrixXd ret = MatrixXd::Zero(X1.rows(),X2.cols());
    for(int i = 0; i < X1.rows(); i++){
        for(int j = 0; j < X2.cols(); j++){
            float acc = 0; 
            for(int k = 0; k < X1.cols(); k++){ acc += X1(i,k)*X2(k,j); }
            ret(i,j) = acc;
    }}
    return ret;
}

MatrixXd relu_prime(MatrixXd zed){
    MatrixXd ret = MatrixXd::Zero(zed.rows(),zed.cols());
    for(int i = 0; i < zed.rows(); i++){
        for(int j = 0; j < zed.cols(); j++){
            if(zed(i,j) > 0){ ret(i,j) = 1; } 
    }}
    return ret;
}

MatrixXd r_maxpool(const MatrixXd& R, const MatrixXd& M, const MatrixXd& dM){
    MatrixXd ret(R.rows(),R.cols());
    for(int i = 0; i < R.rows(); i++){
        for(int j = 0; j < R.cols(); j++){
            if(pow(R(i,j) - M(i/2,j/2),2) < 0.001){ ret(i,j) = dM(i/2,j/2);} 
            else { ret(i,j) = 0; }
    }}
    return ret;
}

MatrixXd conv(const MatrixXd& X, const MatrixXd& K, const float& b){
    int Xs = X.rows();
    int Ks = K.rows();
    int Ys = Xs - Ks + 1;
    MatrixXd Y = Eigen::MatrixXd::Zero(Ys, Ys);
    for(int i = 0; i < Ys; i++){
        for(int j = 0; j < Ys; j++){
            float MAC = 0;
            for(int u = 0; u < Ks; u++){
                for(int v = 0; v < Ks; v++){
                    MAC += X(i+u,j+v) * K(u,v);
            }}
            Y(i,j) = MAC + b;
    }}
    return Y;
}

MatrixXd maxpool(const MatrixXd& input) {
    MatrixXd pooledMatrix(input.rows()/2, input.cols()/2);
    for (int i = 0; i < input.rows()/2; ++i) {
        for (int j = 0; j < input.cols()/2; ++j) {
            MatrixXd window = input.block(i * 2, j * 2, 2, 2);
            double maxValue = window.maxCoeff();
            pooledMatrix(i, j) = maxValue;
    }}
    return pooledMatrix;
}

MatrixXd vectorToEigenMatrix(const std::vector<float>& inputVector, int rows, int cols) {
    if (rows * cols != inputVector.size()) {
        std::cerr << "Error: Dimensions mismatch." << std::endl;
        return MatrixXd();
    }
    return Map<const Matrix<float, Dynamic, Dynamic, RowMajor>>(inputVector.data(), rows, cols).cast<double>();
}

MatrixXd readCSV(const std::string& filePath) {
    // Open the CSV file
    std::ifstream file(filePath);
    if (!file.is_open()) {
        throw std::runtime_error("Error opening file: " + filePath);
    }
    std::cout << "reading csv from: " << filePath;
    // Read data from the CSV file
    std::vector<std::vector<float>> data;
    std::string line;
    while (std::getline(file, line)) {
        std::vector<float> row;
        std::stringstream lineStream(line);
        float value;
        while (lineStream >> value) {
            row.push_back(value);
            if (lineStream.peek() == ',') {
                lineStream.ignore();
            }
        }
        data.push_back(row);
    }

    // Close the file
    file.close();

    // Convert data to Eigen::MatrixXd
    int numRows = data.size();
    int numCols = data[0].size();
    Eigen::MatrixXd matrix(numRows, numCols);
    for (int i = 0; i < numRows; ++i) {
        for (int j = 0; j < numCols; ++j) {
            matrix(i, j) = data[i][j];
        }
    }
    std::cout << "\tfinished "<< std::endl;
    return matrix;
}



int argmax(const VectorXd& vect){
    float max = vect.maxCoeff();
    for(int i = 0; i < vect.size(); i++){
        if(pow(vect(i) - max,2) < 0.0001){
            return i; 
        }
    }
}

Eigen::MatrixXd vect_readCSV(const std::string& filename) {
    // Open the CSV file
    std::ifstream file(filename);
    if (!file.is_open()) {
        throw std::runtime_error("Error opening file: " + filename);
    }

    // Read data from the CSV file
    std::vector<std::vector<float>> data;
    std::string line;
    while (std::getline(file, line)) {
        std::vector<float> row;
        std::stringstream lineStream(line);
        float value;
        while (lineStream >> value) {
            row.push_back(value);
            if (lineStream.peek() == ',') {
                lineStream.ignore();
            }
        }
        data.push_back(row);
    }

    // Close the file
    file.close();



    // Convert data to Eigen::MatrixXd
    int numRows = data.size();
    int numCols = data[0].size();
    Eigen::MatrixXd matrix(numRows, numCols);
    for (int i = 0; i < numRows; ++i) {
        for (int j = 0; j < numCols; ++j) {
            matrix(i, j) = data[i][j];
        }
    }

    return matrix;
}
