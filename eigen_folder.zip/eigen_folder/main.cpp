#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>
#include <random>
#include <Eigen/Dense>

using namespace Eigen;

//HYPER PARAMETERS 
const int filter_size = 3; 

MatrixXd readCSV(const std::string& filePath);
MatrixXd convolve(const MatrixXd& X, const MatrixXd& K, const float& b);
MatrixXd maxpool(const MatrixXd& input);
MatrixXd reverse_maxpool(const MatrixXd& Z, const MatrixXd& M, const MatrixXd& dM);
MatrixXd DOT(const MatrixXd& X1, const MatrixXd& X2);
VectorXd readCSVtoVector(const std::string& filename);
void saveMatrixToCSV(const Eigen::MatrixXd& matrix, const std::string& filename);
int argmax(const VectorXd& vect);
void saveVectorToCSV(const Eigen::VectorXd& eigenVector, const std::string& fileName);
void updateV(Eigen::VectorXd& X, const Eigen::VectorXd& dX);
MatrixXd updateM(const Eigen::MatrixXd& X, const Eigen::MatrixXd& dX);

const float eta = 0.005; 
const float delta = 0.00000000001;

int main(int argc, char* argv[]){
    const int filters = 32; 

    //READING LABELS AND IMAGES
    MatrixXd csvdata = readCSV("mini.csv");
    VectorXd labels = csvdata.col(0);
    MatrixXd images(csvdata.rows(), csvdata.cols() - 1);
    images << csvdata.rightCols(csvdata.cols() - 1);

    //INITIALIZING VARIABLES 
    Matrix<double,3,3> K[filters], dK[filters];
    Matrix<double,26,26> Z[filters], dZ[filters];
    Matrix<double,13,13> M[filters], dM[filters];

    //READING PARAMETERS 
    VectorXd B = readCSVtoVector("B.csv");
    for(int i = 0; i < filters; i++){ K[i] = readCSV("kernels/K"+std::to_string(i)+".csv"); }
    MatrixXd W = readCSV("W.csv");
    std::cout << "W shape: (" << W.rows() << ", "<< W.cols() << ") " << std::endl; 

    //MAIN LOOP 
    const int trials = 2000;
    const int desired_sample_size = 20000;
    const int sample_size = std::min(desired_sample_size, images.rows());
    const int save = 2000; 
    const int measure = 1000;

    VectorXd acc = VectorXd::Zero(measure);
    VectorXd err = VectorXd::Zero(measure);
    
    for(int trial = 0; trial < trials; trial++){
        //PRELIMINARY CALCULATIONS
        int number = trial%sample_size;
        VectorXd Y_act = VectorXd::Constant(10, 5); Y_act(static_cast<int>(labels(number))) = 10;

        //READING INPUT AND NORMALIZING
        MatrixXd in = images.row(number).reshaped(28,28).transpose();
        MatrixXd input = in/in.norm();

        //FORWARD PROPAGATION
        for(int i = 0; i < filters; i++){
            Z[i] = convolve(input, K[i], B(i));
            M[i] = maxpool(Z[i]);
        }

        VectorXd M_FLAT = VectorXd::Zero(169*filters);
        for(int i = 0; i < filters; i++){ M_FLAT.segment(169*i,169) = M[i].reshaped(); }s
        VectorXd Y_hat = W*M_FLAT;

        //OUTPUTTING RESULTS
        if(argmax(Y_hat) == static_cast<int>(labels(number))) { acc(trial%measure) = 1; } 
        else { acc(trial%measure) = 0; }
      
        VectorXd dY_hat = Y_hat - Y_act;
        err(trial%measure) = dY_hat.norm();

        std::cout << "TRIAL: " << trial <<"\tERROR: " << dY_hat.norm() << "\tLABEL: "<< labels[number] 
        << "\tACCURACY: " << acc.mean() << "\tERR: " << err.mean() << std::endl;

        //BACK PROPAGATION
        VectorXd DM_FLAT = VectorXd::Zero(W.cols());
        for(int i = 0; i < W.cols(); i++){
            for(int j = 0; j < W.rows(); j++){ DM_FLAT(i) = DM_FLAT(i) + dY_hat(j)*W(j,i);}
        }

        MatrixXd dW = MatrixXd::Zero(W.rows(),W.cols());
        for(int i = 0; i < W.rows(); i++){
            for(int j = 0; j < W.cols(); j++){ dW(i,j) = dY_hat(i)*M_FLAT(j); }
        }
        
        for(int i = 0; i < filters; i++){
            dM[i] = DM_FLAT.segment(i*169,169).reshaped(13,13); 
            dZ[i] = reverse_maxpool(Z[i],M[i],dM[i]); 
            dK[i] = convolve(input, dZ[i],0); 
        }
    
        //UPDATING WEIGHTS
        for(int i = 0; i < filters; i++){ K[i] = updateM(K[i],dK[i]); }
        B -= B * eta * B.norm()/(dY_hat.norm()+delta);
        W = updateM(W,dW);
        
        //SAVING WEIGHTS TO FILES
        if(trial%save == save-1){
            for(int i = 0; i < filters; i++){ saveMatrixToCSV(K[i],"kernels/K"+std::to_string(i)+".csv"); }
            saveVectorToCSV(B,"B.csv");
            saveMatrixToCSV(W,"W.csv");
        }
    }

    std::cout << "hello world " << std::endl;
    return 0; 
}

void updateV(Eigen::VectorXd& X, const Eigen::VectorXd& dX){
    float mult = eta*X.norm()/(dX.norm() + delta);
    X = X - mult*dX;
}

MatrixXd updateM(const Eigen::MatrixXd& X, const Eigen::MatrixXd& dX){
    float mult = eta*X.norm()/(dX.norm() + delta);
    return X - mult*dX;
}

void saveVectorToCSV(const Eigen::VectorXd& eigenVector, const std::string& fileName) {
    std::ofstream csvFile(fileName);
    if (csvFile.is_open()) {
        for (int i = 0; i < eigenVector.size(); ++i) {
            csvFile << eigenVector(i);
            if (i < eigenVector.size() - 1) { csvFile << ","; }
        }
        csvFile.close();

        std::cout << "Eigen vector saved to " << fileName << std::endl;
    } else { std::cerr << "Unable to open CSV file for writing." << std::endl; }
}

VectorXd readCSVtoVector(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return Eigen::VectorXd();  // Return an empty vector in case of an error
    }
    std::vector<double> data;
    double value;
    while (file >> value) {
        data.push_back(value);
        char comma;
        file >> std::ws >> comma; // Read and discard the comma (if any) after each value
    }
    file.close();
    int size = data.size();
    Eigen::Map<Eigen::VectorXd> vector(data.data(), size);
    return vector;
}

MatrixXd DOT(const MatrixXd& X1, const MatrixXd& X2){
    MatrixXd ret = MatrixXd::Zero(X1.rows(),X2.cols());
    for(int i = 0; i < X1.rows(); i++){
        for(int j = 0; j < X2.cols(); j++){
            float acc = 0; 
            for(int k = 0; k < X1.cols(); k++){ acc += X1(i,k)*X2(k,j); }
            ret(i,j) = acc;
    }}
    return ret;
}

MatrixXd reverse_maxpool(const MatrixXd& Z, const MatrixXd& M, const MatrixXd& dM){
    MatrixXd ret(Z.rows(),Z.cols());
    for(int i = 0; i < Z.rows(); i++){
        for(int j = 0; j < Z.cols(); j++){
            if(pow(Z(i,j) - M(i/2,j/2),2) < 0.001){ ret(i,j) = dM(i/2,j/2);} 
            else { ret(i,j) = 0; }
    }}
    return ret;
}

MatrixXd convolve(const MatrixXd& X, const MatrixXd& K, const float& b){
    int Xs = X.rows(); int Ks = K.rows(); int Ys = Xs - Ks + 1;
    MatrixXd Y = Eigen::MatrixXd::Zero(Ys, Ys);
    for(int i = 0; i < Ys; i++){
        for(int j = 0; j < Ys; j++){
            float MAC = 0;
            for(int u = 0; u < Ks; u++){
                for(int v = 0; v < Ks; v++){
                    MAC += X(i+u,j+v) * K(u,v);
            }}
            Y(i,j) = MAC + b;
    }}
    return Y;
}

MatrixXd maxpool(const MatrixXd& input) {
    MatrixXd pooledMatrix(input.rows()/2, input.cols()/2);
    for (int i = 0; i < input.rows()/2; ++i) {
        for (int j = 0; j < input.cols()/2; ++j) {
            MatrixXd window = input.block(i * 2, j * 2, 2, 2);
            double maxValue = window.maxCoeff();
            pooledMatrix(i, j) = maxValue;
    }}
    return pooledMatrix;
}

MatrixXd readCSV(const std::string& filePath) {
    std::ifstream file(filePath);
    if (!file.is_open()) { throw std::runtime_error("Error opening file: " + filePath); }
    std::cout << "reading csv from: " << filePath;
    std::vector<std::vector<float>> data;
    std::string line;
    while (std::getline(file, line)) {
        std::vector<float> row;
        std::stringstream lineStream(line);
        float value;
        while (lineStream >> value) {
            row.push_back(value);
            if (lineStream.peek() == ',') { lineStream.ignore(); }
        }
        data.push_back(row);
    }
    file.close();
    int numRows = data.size();
    int numCols = data[0].size();
    Eigen::MatrixXd matrix(numRows, numCols);
    for (int i = 0; i < numRows; ++i) {
        for (int j = 0; j < numCols; ++j) { matrix(i, j) = data[i][j]; }
    }
    std::cout << "\tfinished "<< std::endl;
    return matrix;
}

void saveMatrixToCSV(const Eigen::MatrixXd& matrix, const std::string& filename) {
    std::ofstream file(filename);
    if (file.is_open()) {
        file << matrix.format(Eigen::IOFormat(Eigen::StreamPrecision, Eigen::DontAlignCols, ", ", "\n"));
        file.close();
        std::cout << "Matrix saved to " << filename << std::endl;
    } else {std::cerr << "Error opening file: " << filename << std::endl;}
}

int argmax(const VectorXd& vect){
    float max = vect.maxCoeff();
    for(int i = 0; i < vect.size(); i++){
        if(pow(vect(i) - max,2) < 0.0001){ return i; }
    }
}