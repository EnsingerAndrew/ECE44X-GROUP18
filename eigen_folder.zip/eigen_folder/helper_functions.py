import numpy as np
from PIL import Image
import random
import math 
import os
import pandas as pd
import matplotlib.pyplot as plt

def mat(row,col):
    return np.zeros((row,col))

def mat2(row,col,initial):
    mat = np.zeros((row,col))
    for i in range(row):
        for j in range(col):
            if(initial): mat[i][j] = initial
            else: mat[i][j] = (i+1)*(j+1)
    return mat

def mat3(row,col):
    mat = np.zeros((row,col))
    for i in range(row):
        for j in range(col):
            mat[i][j] = round(random.uniform(-3,3),3)
    return mat

def CONV(input, kernel):
    rows = input.shape[0] - kernel.shape[0] + 1
    cols = input.shape[1] - kernel.shape[1] + 1
    ret = mat(rows,cols)
    for i in range(rows):
        for j in range(cols):
            for u in range(kernel.shape[0]):
                for v in range(kernel.shape[1]):
                    ret[i][j] = ret[i][j] + input[i+u][j+v]*kernel[u][v]
    return ret

def RELU(input):
    ret = np.copy(input)
    ret[ret < 0] = 0
    return ret

def MAXPOOL(input):
    kernel_size = 2 
    rows = int(input.shape[0]/kernel_size)
    cols = int(input.shape[1]/kernel_size)
    ret = mat(rows,cols)
    for i in range(rows):
        for j in range(cols):
            for u in range(kernel_size):
                for v in range(kernel_size):
                    ret[i][j] = max(ret[i][j],input[i*kernel_size + u][j*kernel_size + v])
    return ret

def FLATTEN_SET(set):
    vec_set = [np.zeros(set[0].shape[0] * set[0].shape[1])] * len(set)
    for i in range(len(set)):
        vec_set[i] = set[i].flatten(order='F')

    ret = vec_set[0]
    for i in range(len(set) - 1):
        ret = np.concatenate((ret,vec_set[i+1]),axis=0)
    return ret


def image(filename):
    return np.array(Image.open(filename))

def csv(filename):
    return np.genfromtxt(filename, delimiter=',')


def prnt(mat):
    for row in range(mat.shape[0]):
        for col in range(mat.shape[1]):
            print(round(mat[row][col],5),end="")
            for i in range(max(1,8-len(str(round(mat[row][col],5))) + 1)):
                print(" ",end="")
        print("")
    print("")

def pv(vect):
    for row in range(vect.shape[0]):
        print(round(vect[row],4),end="")
        for i in range(max(1,7-len(str(round(vect[row],4))) + 1)):
            print(" ",end="")
    print("")

def resetK(): 
    for i in range(10): np.savetxt("kernels/K"+str(i)+".csv", csv("kernels/K"+str(i)+"_0.csv"), delimiter=',')

def GENMAT(FILENAME, ROWS, COLS,LOWER_BOUND=-0.01, UPPER_BOUND=0.01):
    random_matrix = np.random.uniform(LOWER_BOUND, UPPER_BOUND, size=(ROWS, COLS))
    np.savetxt(FILENAME, random_matrix, delimiter=',')


def GEN_K(filename, rows,columns):
    random_matrix = np.random.uniform(-0.01, 0.01, size=(rows, columns))
    random_matrix[1][1] = 1
    np.savetxt(filename, random_matrix, delimiter=',')


filters = 32
# for i in range(filters):
#     GEN_K("kernels/K"+str(i)+".csv",3,3)
#GENMAT("W.csv", 10,169*filters,0,0.01)


# GEN_W("tensors/U0.csv",10,7,0.1)
# GEN_W("tensors/U1.csv",13,9,0.1)
# GEN_W("tensors/U2.csv",13,9,0.1)
# GEN_W("tensors/U3.csv",13,7,0.1)

# GEN_G("G.csv",4900)
    
def plotFloatsFromCSV(csv_file):
    # Read the CSV file into a DataFrame
    df = pd.read_csv(csv_file, header=None)

    # Extract the single row of floats
    data_row = df.iloc[0]

    # Create a plot
    plt.plot(data_row)

    # Customize the plot as needed
    plt.title('Floats from CSV File')
    plt.xlabel('Index')
    plt.ylabel('Values')

    # Show the plot
    plt.show()


# plotFloatsFromCSV("acc_save.csv")
plotFloatsFromCSV("err_save.csv")









def DOT(mat1,mat2):
    return np.dot(mat1,mat2)

def SOFTMAX(vect):
    ret = np.zeros(vect.shape[0])

    sum = 0
    for i in range(vect.shape[0]):
        sum = sum + math.e**vect[i]
    for i in range(vect.shape[0]):
        ret[i] = math.e**vect[i] / sum
    return ret

def SIGMOID(vect):
    ret = np.zeros(vect.shape)
    for i in range(vect.shape[0]):
        ret[i] = 1/(1 + math.e**(-vect[i]))
    return ret

def SIGMOID_PRIME(vect):
    S = SIGMOID(vect)
    ret = np.zeros(vect.shape)
    for i in range(vect.shape[0]): 
        ret[i] = S[i]*(1-S[i])
    return ret

def JACOBIAN(vect):
    ret = np.zeros((vect.shape[0],vect.shape[0]))
    S = SOFTMAX(vect)
    for i in range(vect.shape[0]):
        for j in range(vect.shape[0]):
            if( i == j ):
                ret[i][j] = S[i]*(1 - S[j])
            else: 
                ret[i][j] = -1*S[i]*S[j]
    return ret

def NORMALIZE(NP):
    norm = np.linalg.norm(NP)
    return (NP / norm)

#ASSUMES K = 2
def REVERSE_MAXPOOL(R,M,dM):
    ret = np.copy(R)
    for i in range(len(R)):
        for j in range(len(R[0])):
            if((R[i][j] - M[int(i/2)][int(j/2)])**2 < 0.0001): 
                ret[i][j] = round(dM[int(i/2)][int(j/2)],4)
            else:
                ret[i][j] = 0
    return ret

def RELU_PRIME(Z):
    ret = np.copy(Z)
    for i in range(len(Z)):
        for j in range(len(Z[0])):
            if(Z[i][j] < 0): 
                ret[i][j] = 0
            else: 
                ret[i][j] = 1
    return ret

def get_file(directory_path):
    filenames = os.listdir(directory_path)
    if not filenames:
        return None  # Return None if the directory is empty

    random_filename = random.choice(filenames)
    return random_filename